// Layout data extractor using Cheerio
// Reads input.html, parses improvements to infer exterior spaces like Open Porch and Sheds, maps to schema

const fs = require("fs");
const path = require("path");
const cheerio = require("cheerio");

function getText($, el) {
  if (!el || el.length === 0) return "";
  return $(el).text().replace(/\s+/g, " ").trim();
}

function parseNumber(str) {
  if (!str) return null;
  const n = parseFloat(String(str).replace(/[^0-9.\-]/g, ""));
  return Number.isFinite(n) ? n : null;
}

function ensureDir(dir) {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
}

function extractPropertyId($) {
  let pid = getText($, $('th:contains("Property ID:")').first().next("td"));
  if (!pid) {
    const title = getText($, $(".page-title h3").first());
    const m = title.match(/Property ID:\s*(\d+)/i);
    if (m) pid = m[1];
  }
  return pid || "unknown";
}

function extractLivingArea($) {
  let sqft = null;
  $('.panel .panel-heading:contains("Property Improvement - Building")').each(
    (_, heading) => {
      const panel = $(heading).closest(".panel");
      $(panel)
        .find(".panel-table-info span,strong")
        .each((__, node) => {
          const t = getText($, node);
          const m = t.match(/Living Area:\s*([0-9,.]+)\s*sqft/i);
          if (m) {
            const n = parseNumber(m[1]);
            if (Number.isFinite(n)) sqft = n;
          }
        });
    },
  );
  return sqft;
}

function makeNeutralRoom(spaceType, index, sizeSqft, isExterior) {
  return {
    space_type: spaceType,
    space_index: index,
    flooring_material_type: null,
    size_square_feet: sizeSqft || null,
    floor_level: null,
    has_windows: null,
    window_design_type: null,
    window_material_type: null,
    window_treatment_type: null,
    is_finished: isExterior ? false : true,
    furnished: null,
    paint_condition: null,
    flooring_wear: null,
    clutter_level: null,
    visible_damage: null,
    countertop_material: null,
    cabinet_style: null,
    fixture_finish_quality: null,
    design_style: null,
    natural_light_quality: null,
    decor_elements: null,
    pool_type: null,
    pool_equipment: null,
    spa_type: null,
    safety_features: null,
    view_type: null,
    lighting_features: null,
    condition_issues: null,
    is_exterior: !!isExterior,
    pool_condition: null,
    pool_surface_type: null,
    pool_water_quality: null,

    // optional dates
    bathroom_renovation_date: null,
    flooring_installation_date: null,
    kitchen_renovation_date: null,
    spa_installation_date: null,
    pool_installation_date: null,
  };
}

function parseImprovementsToLayouts($, startIndex) {
  const layouts = [];
  let idx = startIndex;

  // Find building improvements table: contains rows with Type / Description / SQFT
  $('.panel .panel-heading:contains("Property Improvement - Building")').each(
    (_, heading) => {
      const panel = $(heading).closest(".panel");
      const tables = $(panel).find("table");

      tables.each((__, tbl) => {
        const headerText = getText(
          $,
          $(tbl).prevAll(".panel-table-info").first(),
        );
        // Determine if this table is the outbuildings table by reading preceding info 'Description: OUT BLDGS'
        const isOutBuildings = /Description:\s*OUT BLDGS/i.test(headerText);

        $(tbl)
          .find("tr")
          .each((___, tr) => {
            const $cells = $(tr).find("td");
            if ($cells.length >= 5) {
              const type = getText($, $cells.eq(0));
              const desc = getText($, $cells.eq(1));
              const sqft = parseNumber(getText($, $cells.eq(4)));

              // Map OPEN PORCH to Open Porch layout
              if (/OPEN PORCH/i.test(desc)) {
                layouts.push(makeNeutralRoom("Open Porch", idx++, sqft, true));
              }

              // Map barns as Sheds
              if (isOutBuildings && /BARN/i.test(desc)) {
                layouts.push(makeNeutralRoom("Shed", idx++, sqft, true));
              }
            }
          });
      });
    },
  );

  return { layouts, nextIndex: idx };
}

function mapLayouts($) {
  const propertyId = extractPropertyId($);

  const livingArea = extractLivingArea($);
  const layouts = [];
  let index = 1;

  // Generic interior space representing main living area footprint (no detailed rooms available)
  layouts.push(makeNeutralRoom("Living Room", index++, livingArea, false));

  // Parse improvements to add porches and sheds
  const { layouts: extraLayouts, nextIndex } = parseImprovementsToLayouts(
    $,
    index,
  );
  layouts.push(...extraLayouts);
  index = nextIndex;

  return { key: `property_${propertyId}`, data: { layouts } };
}

function main() {
  const inputPath = path.join(process.cwd(), "input.html");
  const html = fs.readFileSync(inputPath, "utf8");
  const $ = cheerio.load(html);

  const { key, data } = mapLayouts($);

  const outDir = path.join(process.cwd(), "owners");
  ensureDir(outDir);
  const outPath = path.join(outDir, "layout_data.json");

  const output = {};
  output[key] = data;

  fs.writeFileSync(outPath, JSON.stringify(output, null, 2), "utf8");
  console.log(`Wrote layout data for ${key} -> ${outPath}`);
}

if (require.main === module) {
  try {
    main();
  } catch (err) {
    console.error("Error generating layout data:", err.message);
    process.exit(1);
  }
}
