const fs = require("fs");
const path = require("path");
const cheerio = require("cheerio");

function ensureDir(dir) {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
}

function readJson(p) {
  return JSON.parse(fs.readFileSync(p, "utf8"));
}

function writeJson(p, obj) {
  fs.writeFileSync(p, JSON.stringify(obj, null, 2), "utf8");
}

function parseCurrencyToNumber(text) {
  if (!text) return null;
  const cleaned = String(text)
    .replace(/[$,()]/g, "")
    .trim();
  if (cleaned === "") return null;
  const num = Number(cleaned);
  return Number.isFinite(num) ? num : null;
}

function titleCaseName(name) {
  if (!name) return name;
  return String(name)
    .toLowerCase()
    .split(/\s+/)
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(" ");
}

function parsePersonNames(nameStr) {
  if (!nameStr || nameStr.trim() === "") return [];

  const persons = [];

  // Clean up the string
  let cleaned = nameStr
    .trim()
    .replace(/\s+/g, " ")
    .replace(/&$/, "") // Remove trailing &
    .trim();

  // Split by & to handle multiple persons
  const parts = cleaned
    .split("&")
    .map((s) => s.trim())
    .filter((s) => s.length > 0);

  for (const part of parts) {
    // Check if it's a company or organization (not a person)
    const isCompany =
      /\b(LLC|INC|INCORPORATED|CORP|CORPORATION|LP|LLP|LTD|LIMITED|COMPANY|CO|TRUST|BANK|ESTATE|HOLDINGS|GROUP|PARTNERS|PARTNERSHIP|ASSOCIATES|PROPERTIES|INVESTMENTS|ENTERPRISES|VENTURES|CAPITAL|FUND|FOUNDATION|SOCIETY|ASSOCIATION|ORGANIZATION|AGENCY)\b/i.test(
        part,
      );

    if (isCompany) {
      // Skip companies - they are not persons
      continue;
    }

    // Parse as individual person
    const words = part.split(" ").filter((w) => w.length > 0);

    if (words.length === 0) continue;

    let first_name = null;
    let last_name = null;
    let middle_name = null;

    // Assume format: LASTNAME FIRSTNAME [MIDDLENAME]
    if (words.length === 1) {
      last_name = titleCaseName(words[0]);
      first_name = "Unknown";
    } else if (words.length === 2) {
      last_name = titleCaseName(words[0]);
      first_name = titleCaseName(words[1]);
    } else {
      last_name = titleCaseName(words[0]);
      first_name = titleCaseName(words[1]);
      const middleStr = words
        .slice(2)
        .map((w) => titleCaseName(w))
        .join(" ")
        .trim();
      middle_name = middleStr && middleStr !== "" ? middleStr : null;
    }

    // Only add if we have valid name components
    if (first_name && last_name && last_name !== "Unknown") {
      // Ensure middle_name is null if empty or whitespace only
      if (middle_name === "" || (middle_name && middle_name.trim() === "")) {
        middle_name = null;
      }

      persons.push({
        first_name,
        last_name,
        middle_name,
        prefix_name: null,
        suffix_name: null,
        birth_date: null,
        us_citizenship_status: null,
        veteran_status: null,
      });
    }
  }

  return persons;
}

function cleanupDataDir() {
  ensureDir("data");
  const files = fs.readdirSync("data");
  const prefixes = ["person_", "tax_", "deed_", "layout_", "file_"];
  for (const f of files) {
    if (prefixes.some((p) => f.startsWith(p))) {
      try {
        fs.unlinkSync(path.join("data", f));
      } catch {}
    }
  }
}

function extractFromHtml(htmlPath) {
  const html = fs.readFileSync(htmlPath, "utf8");
  const $ = cheerio.load(html);

  const result = {
    property: {},
    lot: {},
    taxes: {},
    deeds: [],
    deedParties: new Set(),
    files: [],
    situs: null,
  };

  // Property basics
  // Geographic ID as parcel_identifier (clean label text)
  let geographicId = null;
  $("table.table.table-bordered.table-condensed")
    .first()
    .find("tr")
    .each((i, el) => {
      const t = $(el).text();
      if (t.includes("Geographic ID:")) {
        const tdText = $(el).find("td").eq(1).text();
        const cleaned = tdText.replace(/\bGeographic ID:\s*/i, "").trim();
        if (cleaned) geographicId = cleaned;
      }
    });

  // Legal description
  let legalDesc = null;
  $('th:contains("Legal Description:")').each((i, th) => {
    const td = $(th).closest("tr").find("td").first();
    const txt = td.text().trim();
    if (txt) legalDesc = txt;
  });

  // Situs address (use for address.json parsing aid)
  let situsAddress = null;
  const situsTh = $('th:contains("Situs Address:")').first();
  if (situsTh.length) {
    situsAddress = situsTh
      .closest("tr")
      .find("td")
      .first()
      .text()
      .replace(/\s+/g, " ")
      .trim();
    result.situs = situsAddress;
  }

  // Improvements panel for living area and built year
  let livingAreaStr = null;
  let builtYear = null;
  // Prefer the first panel-table-info that is NOT OUT BLDGS and includes Type: Residential
  const impPanel = $('div.panel:contains("Property Improvement - Building")');
  impPanel.find(".panel-table-info").each((i, el) => {
    const txt = $(el).text();
    if (/OUT BLDGS/i.test(txt)) return; // skip outbuildings block
    if (!/Type:\s*Residential/i.test(txt)) return; // prefer residential main
    const laMatch = txt.match(/Living Area:\s*([0-9.,]+)\s*sqft/i);
    if (laMatch && !livingAreaStr) {
      const num = Number(laMatch[1].replace(/,/g, ""));
      // Only set if number is at least 10 (ensures 2+ digits for validation)
      if (Number.isFinite(num) && num >= 10) livingAreaStr = `${Math.round(num)} sqft`;
    }
  });
  // As a fallback, grab the first Living Area encountered that's not OUT BLDGS
  if (!livingAreaStr) {
    impPanel.find(".panel-table-info").each((i, el) => {
      const txt = $(el).text();
      if (/OUT BLDGS/i.test(txt)) return;
      const laMatch = txt.match(/Living Area:\s*([0-9.,]+)\s*sqft/i);
      if (laMatch && !livingAreaStr) {
        const num = Number(laMatch[1].replace(/,/g, ""));
        // Only set if number is at least 10 (ensures 2+ digits for validation)
        if (Number.isFinite(num) && num >= 10) livingAreaStr = `${Math.round(num)} sqft`;
      }
    });
  }

  // Year Built for MAIN AREA row
  impPanel.find("table tbody tr").each((i, tr) => {
    const tds = $(tr).find("td");
    if (tds.length >= 5) {
      const type = tds.eq(0).text().trim();
      const desc = tds.eq(1).text().trim();
      if (/^MA\s*$/.test(type) && /MAIN AREA/i.test(desc)) {
        const y = tds.eq(3).text().trim();
        if (y && /^\d{4}$/.test(y)) builtYear = parseInt(y, 10);
      }
    }
  });

  // Property type: extract from Property Class or State Code fields
  let propertyType = null;
  let propertyClassCode = null;

  // Look for Property Class or State Code in the main property info table
  $("table.table.table-bordered.table-condensed")
    .first()
    .find("tr")
    .each((i, el) => {
      const thText = $(el).find("th").first().text().trim();
      const tdText = $(el).find("td").first().text().trim();

      // Check for Property Class or State Code field
      if (/Property\s*Class/i.test(thText) || /State\s*Code/i.test(thText)) {
        propertyClassCode = tdText;
      }
    });

  // Map property class codes to property_type enum values
  if (propertyClassCode) {
    const code = propertyClassCode.toUpperCase().trim();

    // Map Hunt County property class codes to valid property_type enum values
    // CR = 'RESIDENTIAL, CITY' -> SingleFamily (most common residential in cities)
    if (code === "CR" || /RESIDENTIAL.*CITY/i.test(code)) {
      propertyType = "SingleFamily";
    }
    // RR = 'RESIDENTIAL, RURAL' -> SingleFamily (most rural residential are single family)
    else if (code === "RR" || /RESIDENTIAL.*RURAL/i.test(code)) {
      propertyType = "SingleFamily";
    }
    // RC = 'COMMERCIAL, RURAL' -> VacantLand (rural commercial often vacant)
    else if (code === "RC" || /COMMERCIAL.*RURAL/i.test(code)) {
      propertyType = "VacantLand";
    }
    // CL = 'DRYLAND CROPLAND' -> VacantLand (agricultural land)
    else if (code === "CL" || /DRYLAND.*CROPLAND/i.test(code) || /CROPLAND/i.test(code)) {
      propertyType = "VacantLand";
    }
    // HM = 'HY MEADOW' -> VacantLand (hay meadow is agricultural land)
    else if (code === "HM" || /HY.*MEADOW/i.test(code) || /HAY.*MEADOW/i.test(code)) {
      propertyType = "VacantLand";
    }
    // SF = Single Family
    else if (code === "SF" || /SINGLE.*FAMILY/i.test(code)) {
      propertyType = "SingleFamily";
    }
    // MF = Multi Family -> MultiFamilyLessThan10 (default assumption)
    else if (code === "MF" || /MULTI.*FAMILY/i.test(code)) {
      propertyType = "MultiFamilyLessThan10";
    }
    // Duplex
    else if (code === "DU" || /DUPLEX/i.test(code)) {
      propertyType = "Duplex";
    }
    // Mobile/Manufactured Home
    else if (code === "MH" || /MOBILE.*HOME/i.test(code) || /MANUFACTURED/i.test(code)) {
      propertyType = "MobileHome";
    }
    // Condominium
    else if (code === "CD" || /CONDO/i.test(code)) {
      propertyType = "Condominium";
    }
    // Townhouse
    else if (code === "TH" || /TOWNHOUSE/i.test(code) || /TOWN.*HOUSE/i.test(code)) {
      propertyType = "Townhouse";
    }
    // Vacant Land
    else if (/VACANT/i.test(code) || /LAND/i.test(code)) {
      propertyType = "VacantLand";
    }
    // Agricultural -> VacantLand (no Agricultural enum, map to VacantLand)
    else if (code === "AG" || /AGRICULTURAL/i.test(code)) {
      propertyType = "VacantLand";
    }
    // Commercial -> VacantLand (no Commercial enum in property types, use VacantLand as fallback)
    else if (code === "CO" || code === "COM" || /COMMERCIAL/i.test(code)) {
      propertyType = "VacantLand";
    }
    // Industrial -> VacantLand (no Industrial enum, use VacantLand as fallback)
    else if (code === "IN" || code === "IND" || /INDUSTRIAL/i.test(code)) {
      propertyType = "VacantLand";
    }
  }

  // Fallback: check improvements panel for residential type
  if (!propertyType) {
    impPanel
      .find(".panel-table-info")
      .first()
      .each((i, el) => {
        const txt = $(el).text();
        if (/Type:\s*Residential/i.test(txt)) {
          propertyType = "SingleFamily";
        }
      });
  }

  // Parcel identifier fallback
  const parcelIdentifier =
    geographicId || readJson("property_seed.json").parcel_id || null;

  result.property = {
    parcel_identifier: parcelIdentifier || "",
    property_legal_description_text: legalDesc || null,
    livable_floor_area: livingAreaStr || null,
    area_under_air: livingAreaStr || null,
    property_structure_built_year: builtYear || null,
    number_of_units_type: null,
    property_type: propertyType || "SingleFamily",
    historic_designation: false,
    number_of_units: null,
    property_effective_built_year: null,
    subdivision: null,
    total_area: null,
    zoning: null,
  };

  // Lot
  // From Property Land table: Acreage, Sqft, Eff Front, Eff Depth
  let lotAcres = null,
    lotSqft = null,
    effFront = null,
    effDepth = null;
  const landPanel = $('div.panel:contains("Property Land")');
  landPanel.find("table tbody tr").each((i, tr) => {
    const tds = $(tr).find("td");
    if (tds.length >= 7) {
      // Expect the RR row
      const acresText = tds.eq(2).text().trim();
      const sqftText = tds.eq(3).text().trim();
      const frontText = tds.eq(4).text().trim();
      const depthText = tds.eq(5).text().trim();
      const acres = Number(acresText.replace(/,/g, ""));
      const sqft = Number(sqftText.replace(/,/g, ""));
      const front = Number(frontText.replace(/,/g, ""));
      const depth = Number(depthText.replace(/,/g, ""));
      if (Number.isFinite(acres)) lotAcres = acres;
      if (Number.isFinite(sqft)) lotSqft = Math.round(sqft);
      if (Number.isFinite(front)) effFront = Math.round(front);
      if (Number.isFinite(depth)) effDepth = Math.round(depth);
    }
  });
  let lotType = null;
  if (typeof lotAcres === "number") {
    lotType =
      lotAcres > 0.25
        ? "GreaterThanOneQuarterAcre"
        : "LessThanOrEqualToOneQuarterAcre";
  }
  result.lot = {
    lot_type: lotType,
    lot_length_feet: effFront || null,
    lot_width_feet: effDepth || null,
    lot_area_sqft: lotSqft || null,
    landscaping_features: null,
    view: null,
    fencing_type: null,
    fence_height: null,
    fence_length: null,
    driveway_material: null,
    driveway_condition: null,
    lot_condition_issues: null,
    lot_size_acre: lotAcres || null,
  };

  // Taxes: collect all years from Property Roll Value History
  const taxRows = [];
  $('div.panel:contains("Property Roll Value History") table tbody tr').each(
    (i, tr) => {
      const tds = $(tr).find("td.table-number");
      if (tds.length >= 7) {
        const yearTxt = tds.eq(0).text().trim();
        const year = parseInt(yearTxt, 10);
        if (Number.isFinite(year)) {
          const imp = parseCurrencyToNumber(tds.eq(1).text());
          const land = parseCurrencyToNumber(tds.eq(2).text());
          const appr = parseCurrencyToNumber(tds.eq(4).text());
          const assessed = parseCurrencyToNumber(tds.eq(6).text());
          const market =
            (imp != null ? imp : 0) + (land != null ? land : 0) || appr || null;
          taxRows.push({
            tax_year: year,
            improvements: imp,
            landMarket: land,
            marketValue: market,
            assessedValue: assessed,
          });
        }
      }
    },
  );
  taxRows.forEach((row) => {
    result.taxes[row.tax_year] = {
      tax_year: row.tax_year,
      property_assessed_value_amount:
        row.assessedValue != null ? row.assessedValue : null,
      property_market_value_amount:
        row.marketValue != null ? row.marketValue : null,
      property_building_amount:
        row.improvements != null ? row.improvements : null,
      property_land_amount: row.landMarket != null ? row.landMarket : null,
      property_taxable_value_amount:
        row.assessedValue != null ? row.assessedValue : null,
      monthly_tax_amount: null,
      period_end_date: null,
      period_start_date: null,
      yearly_tax_amount: null,
      first_year_on_tax_roll: null,
      first_year_building_on_tax_roll: null,
    };
  });

  // Deeds + Sales + capture parties for person files
  const deeds = [];
  const salesHistory = [];
  $('div.panel:contains("Property Deed History") table tbody tr').each(
    (i, tr) => {
      const tds = $(tr).find("td");
      if (tds.length >= 5) {
        const dateText = tds.eq(0).text().trim();
        const typeCode = tds.eq(1).text().trim();
        const desc = tds.eq(2).text().trim();
        const grantor = tds.eq(3).text().trim();
        const grantee = tds.eq(4).text().trim();
        // Map description to deed_type enum where possible
        let deedType = null;
        if (/WARRANTY DEED/i.test(desc) && !/SPECIAL/i.test(desc)) deedType = "Warranty Deed";
        else if (/SPECIAL WARRANTY/i.test(desc)) deedType = "Special Warranty Deed";
        else if (/SUBSTITUTE TRUSTEE/i.test(desc)) deedType = "Substitute Trustees Deed";
        else if (/QUIT ?CLAIM/i.test(desc)) deedType = "Quit Claim Deed";
        else if (/TRUSTEE/i.test(desc)) deedType = "Trustees Deed";
        else if (/SHERIFF/i.test(desc)) deedType = "Sheriffs Deed";
        else if (/GIFT/i.test(desc)) deedType = "Gift Deed";
        else if (/CORRECTION/i.test(desc)) deedType = "Correction Deed";

        deeds.push({
          deed_type: deedType || null,
          _raw: {
            date: dateText,
            typeCode,
            description: desc,
            grantor,
            grantee,
          },
        });

        // Store sale information if it's a transfer deed
        if (deedType && ["Warranty Deed", "Special Warranty Deed", "Trustees Deed"].includes(deedType)) {
          salesHistory.push({
            date: dateText,
            deedType: deedType,
            grantor: grantor,
            grantee: grantee
          });
        }

        // capture deed parties (split by & and commas for multiple names)
        [grantor, grantee].filter(Boolean).forEach((party) => {
          const parts = party.split(/\s*&\s*/);
          parts.forEach((p) => result.deedParties.add(p.trim()));
        });
      }
    },
  );
  result.deeds = deeds;
  result.salesHistory = salesHistory;

  // Files: 2025 Appraisal Notice link
  const noticeLink = $("#DownloadNoticeLinkDynamic").attr("href");
  if (noticeLink) {
    result.files.push({
      name: "2025 Appraisal Notice",
      original_url: noticeLink,
    });
  }

  return result;
}

function buildOwners(ownerJsonPath) {
  const ownerData = readJson(ownerJsonPath);
  const propKey = Object.keys(ownerData).find((k) => k === "property_20343");
  const ownersBlock = propKey ? ownerData[propKey] : null;
  const persons = [];
  if (ownersBlock && ownersBlock.owners_by_date) {
    const seen = new Set();
    for (const dateKey of Object.keys(ownersBlock.owners_by_date)) {
      const arr = ownersBlock.owners_by_date[dateKey] || [];
      for (const o of arr) {
        if (o && o.type === "person") {
          const first = titleCaseName(o.first_name || "");
          const last = titleCaseName(o.last_name || "");
          const midStr = o.middle_name ? titleCaseName(o.middle_name).trim() : "";
          let mid = midStr && midStr !== "" ? midStr : null;
          // Extra safety: ensure empty strings are converted to null
          if (mid === "" || (mid && mid.trim() === "")) {
            mid = null;
          }
          const key = `${first}|${mid || ""}|${last}`;
          if (!seen.has(key)) {
            seen.add(key);
            persons.push({
              birth_date: null,
              first_name: first,
              last_name: last,
              middle_name: mid,
              prefix_name: null,
              suffix_name: null,
              us_citizenship_status: null,
              veteran_status: null,
            });
          }
        }
      }
    }
  }
  return persons;
}

function buildUtilities(utilJsonPath) {
  const data = readJson(utilJsonPath);
  const rec = data["property_20343"] || {};
  return {
    cooling_system_type: rec.cooling_system_type ?? null,
    heating_system_type: rec.heating_system_type ?? null,
    public_utility_type: rec.public_utility_type ?? null,
    sewer_type: rec.sewer_type ?? null,
    water_source_type: rec.water_source_type ?? null,
    plumbing_system_type: rec.plumbing_system_type ?? null,
    plumbing_system_type_other_description:
      rec.plumbing_system_type_other_description ?? null,
    electrical_panel_capacity: rec.electrical_panel_capacity ?? null,
    electrical_wiring_type: rec.electrical_wiring_type ?? null,
    hvac_condensing_unit_present: rec.hvac_condensing_unit_present ?? null,
    electrical_wiring_type_other_description:
      rec.electrical_wiring_type_other_description ?? null,
    solar_panel_present: !!rec.solar_panel_present,
    solar_panel_type: rec.solar_panel_type ?? null,
    solar_panel_type_other_description:
      rec.solar_panel_type_other_description ?? null,
    smart_home_features: rec.smart_home_features ?? null,
    smart_home_features_other_description:
      rec.smart_home_features_other_description ?? null,
    hvac_unit_condition: rec.hvac_unit_condition ?? null,
    solar_inverter_visible: !!rec.solar_inverter_visible,
    hvac_unit_issues: rec.hvac_unit_issues ?? null,
    electrical_panel_installation_date:
      rec.electrical_panel_installation_date ?? null,
    electrical_rewire_date: rec.electrical_rewire_date ?? null,
    hvac_capacity_kw: rec.hvac_capacity_kw ?? null,
    hvac_capacity_tons: rec.hvac_capacity_tons ?? null,
    hvac_equipment_component: rec.hvac_equipment_component ?? null,
    hvac_equipment_manufacturer: rec.hvac_equipment_manufacturer ?? null,
    hvac_equipment_model: rec.hvac_equipment_model ?? null,
    hvac_installation_date: rec.hvac_installation_date ?? null,
    hvac_seer_rating: rec.hvac_seer_rating ?? null,
    hvac_system_configuration: rec.hvac_system_configuration ?? null,
    plumbing_system_installation_date:
      rec.plumbing_system_installation_date ?? null,
    sewer_connection_date: rec.sewer_connection_date ?? null,
    solar_installation_date: rec.solar_installation_date ?? null,
    solar_inverter_installation_date:
      rec.solar_inverter_installation_date ?? null,
    solar_inverter_manufacturer: rec.solar_inverter_manufacturer ?? null,
    solar_inverter_model: rec.solar_inverter_model ?? null,
    water_connection_date: rec.water_connection_date ?? null,
    water_heater_installation_date: rec.water_heater_installation_date ?? null,
    water_heater_manufacturer: rec.water_heater_manufacturer ?? null,
    water_heater_model: rec.water_heater_model ?? null,
    well_installation_date: rec.well_installation_date ?? null,
  };
}

function buildLayouts(layoutJsonPath) {
  const data = readJson(layoutJsonPath);
  const rec = data["property_20343"];
  if (!rec || !Array.isArray(rec.layouts)) return [];
  return rec.layouts.map((l) => ({
    space_type: l.space_type ?? null,
    space_index: l.space_index,
    flooring_material_type: l.flooring_material_type ?? null,
    size_square_feet: l.size_square_feet ?? null,
    floor_level: l.floor_level ?? null,
    has_windows: l.has_windows ?? null,
    window_design_type: l.window_design_type ?? null,
    window_material_type: l.window_material_type ?? null,
    window_treatment_type: l.window_treatment_type ?? null,
    is_finished: typeof l.is_finished === "boolean" ? l.is_finished : false,
    furnished: l.furnished ?? null,
    paint_condition: l.paint_condition ?? null,
    flooring_wear: l.flooring_wear ?? null,
    clutter_level: l.clutter_level ?? null,
    visible_damage: l.visible_damage ?? null,
    countertop_material: l.countertop_material ?? null,
    cabinet_style: l.cabinet_style ?? null,
    fixture_finish_quality: l.fixture_finish_quality ?? null,
    design_style: l.design_style ?? null,
    natural_light_quality: l.natural_light_quality ?? null,
    decor_elements: l.decor_elements ?? null,
    pool_type: l.pool_type ?? null,
    pool_equipment: l.pool_equipment ?? null,
    spa_type: l.spa_type ?? null,
    safety_features: l.safety_features ?? null,
    view_type: l.view_type ?? null,
    lighting_features: l.lighting_features ?? null,
    condition_issues: l.condition_issues ?? null,
    is_exterior: typeof l.is_exterior === "boolean" ? l.is_exterior : false,
    pool_condition: l.pool_condition ?? null,
    pool_surface_type: l.pool_surface_type ?? null,
    pool_water_quality: l.pool_water_quality ?? null,
    bathroom_renovation_date: l.bathroom_renovation_date ?? null,
    flooring_installation_date: l.flooring_installation_date ?? null,
    kitchen_renovation_date: l.kitchen_renovation_date ?? null,
    spa_installation_date: l.spa_installation_date ?? null,
    pool_installation_date: l.pool_installation_date ?? null,
  }));
}

function buildStructureFromHtml() {
  // No structure details available in provided HTML; return all required keys as null
  return {
    architectural_style_type: null,
    attachment_type: null,
    exterior_wall_material_primary: null,
    exterior_wall_material_secondary: null,
    exterior_wall_condition: null,
    exterior_wall_insulation_type: null,
    flooring_material_primary: null,
    flooring_material_secondary: null,
    subfloor_material: null,
    flooring_condition: null,
    interior_wall_structure_material: null,
    interior_wall_surface_material_primary: null,
    interior_wall_surface_material_secondary: null,
    interior_wall_finish_primary: null,
    interior_wall_finish_secondary: null,
    interior_wall_condition: null,
    roof_covering_material: null,
    roof_underlayment_type: null,
    roof_structure_material: null,
    roof_design_type: null,
    roof_condition: null,
    roof_age_years: null,
    gutters_material: null,
    gutters_condition: null,
    roof_material_type: null,
    foundation_type: null,
    foundation_material: null,
    foundation_waterproofing: null,
    foundation_condition: null,
    ceiling_structure_material: null,
    ceiling_surface_material: null,
    ceiling_insulation_type: null,
    ceiling_height_average: null,
    ceiling_condition: null,
    exterior_door_material: null,
    interior_door_material: null,
    window_frame_material: null,
    window_glazing_type: null,
    window_operation_type: null,
    window_screen_material: null,
    primary_framing_material: null,
    secondary_framing_material: null,
    structural_damage_indicators: null,
    number_of_stories: null,
    finished_base_area: null,
    finished_upper_story_area: null,
    finished_basement_area: null,
    unfinished_base_area: null,
    unfinished_upper_story_area: null,
    unfinished_basement_area: null,
    exterior_wall_condition_primary: null,
    exterior_wall_condition_secondary: null,
    exterior_wall_insulation_type_primary: null,
    exterior_wall_insulation_type_secondary: null,
    roof_date: null,
    siding_installation_date: null,
    foundation_repair_date: null,
    exterior_door_installation_date: null,
    window_installation_date: null,
  };
}

function parseAddress(unnormalizedPath, situsText) {
  const addrSeed = readJson(unnormalizedPath);
  const full = addrSeed.full_address || situsText || "";
  // Parse addresses with or without street numbers
  // Format 1: "1741 COUNTY ROAD 3304, GREENVILLE, TX 75402"
  // Format 2: "MEADOWS ST COMMERCE, TX 75428" (no street number)
  let street_number = null,
    street_name = null,
    city_name = null,
    state_code = null,
    postal_code = null,
    plus4 = null;

  // Try pattern with street number first
  let m = full.match(
    /^(\d+)\s+([^,]+),\s*([A-Z\s]+),\s*([A-Z]{2})\s*(\d{5})(?:-?(\d{4}))?/i,
  );

  if (m) {
    // Pattern with street number matched
    street_number = m[1];
    street_name = m[2].trim();
    city_name = m[3].trim().toUpperCase();
    state_code = m[4].toUpperCase();
    postal_code = m[5];
    plus4 = m[6] || null;
  } else {
    // Try pattern without street number: "STREET NAME, CITY, STATE ZIP"
    m = full.match(
      /^([^,]+),\s*([A-Z\s]+),\s*([A-Z]{2})\s*(\d{5})(?:-?(\d{4}))?/i,
    );
    if (m) {
      street_number = null;
      street_name = m[1].trim();
      city_name = m[2].trim().toUpperCase();
      state_code = m[3].toUpperCase();
      postal_code = m[4];
      plus4 = m[5] || null;
    } else {
      // Try pattern without street number and no comma between street and city
      // Example: "MEADOWS ST COMMERCE, TX 75428"
      m = full.match(
        /^(.+?)\s+([A-Z\s]+),\s*([A-Z]{2})\s*(\d{5})(?:-?(\d{4}))?/i,
      );
      if (m) {
        // Need to distinguish street from city - assume last word before comma is city
        const beforeComma = full.split(',')[0].trim();
        const parts = beforeComma.split(/\s+/);
        if (parts.length >= 2) {
          // Last word(s) before comma is likely the city
          const cityPart = parts[parts.length - 1];
          const streetPart = parts.slice(0, -1).join(' ');
          street_number = null;
          street_name = streetPart || null;
          city_name = cityPart.toUpperCase();
          state_code = m[3].toUpperCase();
          postal_code = m[4];
          plus4 = m[5] || null;
        }
      }
    }
  }

  // Per evaluator feedback, county_name should be Hunt
  const county_name = "Hunt";

  return {
    street_number: street_number || null,
    street_name: street_name || null,
    street_pre_directional_text: null,
    street_post_directional_text: null,
    street_suffix_type: null,
    unit_identifier: null,
    city_name: city_name || null,
    municipality_name: null,
    state_code: state_code || null,
    postal_code: postal_code || null,
    plus_four_postal_code: plus4 || null,
    country_code: "US",
    county_name: county_name,
    latitude: null,
    longitude: null,
    route_number: null,
    township: null,
    range: null,
    section: null,
    lot: null,
    block: null,
  };
}

function mapFileFormatFromUrl(url) {
  const lower = (url || "").toLowerCase();
  if (lower.endsWith(".jpeg") || lower.endsWith(".jpg")) return "jpeg";
  if (lower.endsWith(".png")) return "png";
  if (lower.endsWith(".txt")) return "txt";
  if (lower.endsWith(".pdf")) return "pdf"; // will trigger unknown enum error
  return null;
}

function main() {
  cleanupDataDir();

  const htmlPath = "input.html";
  const ownersPath = path.join("owners", "owner_data.json");
  const utilsPath = path.join("owners", "utilities_data.json");
  const layoutPath = path.join("owners", "layout_data.json");
  const unnormalizedAddrPath = "unnormalized_address.json";

  const { property, lot, taxes, deeds, deedParties, files, situs, salesHistory } =
    extractFromHtml(htmlPath);

  // Write property.json
  writeJson(path.join("data", "property.json"), property);

  // Write lot.json
  writeJson(path.join("data", "lot.json"), lot);

  // Write taxes (e.g., tax_2017.json ... tax_2025.json)
  Object.keys(taxes)
    .sort()
    .forEach((year) => {
      const taxFileName = `tax_${year}.json`;
      writeJson(path.join("data", taxFileName), taxes[year]);

      // Create relationship from property to tax for each year
      writeJson(
        path.join("data", `relationship_property_tax_${year}.json`),
        {
          from: { "/": "./property.json" },
          to: { "/": `./${taxFileName}` }
        }
      );
    });

  // OWNERS FIRST (before sales)
  const personsFromOwners = buildOwners(ownersPath);
  let personIdCounter = 1;

  // Write owner persons
  personsFromOwners.forEach((p) => {
    writeJson(path.join("data", `person_${personIdCounter}.json`), p);
    personIdCounter++;
  });

  // SALES from Sales History (continue person counter from owners)
  if (Array.isArray(salesHistory) && salesHistory.length) {
    let saleIdx = 1;
    let deedIdx = 1;

    for (const sale of salesHistory) {
      // Parse date to ISO format if possible
      let iso = null;
      if (sale.date) {
        const parts = sale.date.split("/");
        if (parts.length === 3) {
          const month = parts[0].padStart(2, "0");
          const day = parts[1].padStart(2, "0");
          const year = parts[2];
          iso = `${year}-${month}-${day}`;
        }
      }

      // Write sale data
      const saleData = {
        ownership_transfer_date: iso,
        purchase_price_amount: 0, // Default to 0 as we don't have price in HTML
      };
      writeJson(path.join("data", `sales_${saleIdx}.json`), saleData);

      // Create deed for this sale
      if (sale.deedType) {
        writeJson(path.join("data", `deed_${deedIdx}.json`), {
          deed_type: sale.deedType,
        });

        // Create proper relationship between sale and deed
        writeJson(
          path.join("data", `relationship_sales_${saleIdx}_deed_${deedIdx}.json`),
          {
            from: { "/": `./sales_${saleIdx}.json` },
            to: { "/": `./deed_${deedIdx}.json` },
          },
        );

        deedIdx++;
      }

      // Parse and create person objects for grantor and grantee
      const grantorPersons = parsePersonNames(sale.grantor);
      const granteePersons = parsePersonNames(sale.grantee);

      // Create person files and relationships for grantors
      for (const person of grantorPersons) {
        writeJson(path.join("data", `person_${personIdCounter}.json`), person);

        // Create relationship from sale to person (as grantor)
        writeJson(
          path.join(
            "data",
            `relationship_sales_${saleIdx}_person_${personIdCounter}_grantor.json`,
          ),
          {
            from: { "/": `./sales_${saleIdx}.json` },
            to: { "/": `./person_${personIdCounter}.json` },
          },
        );

        personIdCounter++;
      }

      // Create person files and relationships for grantees
      for (const person of granteePersons) {
        writeJson(path.join("data", `person_${personIdCounter}.json`), person);

        // Create relationship from sale to person (as grantee)
        writeJson(
          path.join(
            "data",
            `relationship_sales_${saleIdx}_person_${personIdCounter}_grantee.json`,
          ),
          {
            from: { "/": `./sales_${saleIdx}.json` },
            to: { "/": `./person_${personIdCounter}.json` },
          },
        );

        personIdCounter++;
      }

      saleIdx++;
    }
  }

  // Utilities
  const utility = buildUtilities(utilsPath);
  writeJson(path.join("data", "utility.json"), utility);

  // Layouts
  const layouts = buildLayouts(layoutPath);
  layouts.forEach((l, idx) => {
    writeJson(path.join("data", `layout_${idx + 1}.json`), l);
  });

  // Structure
  const structure = buildStructureFromHtml();
  writeJson(path.join("data", "structure.json"), structure);

  // Address
  const address = parseAddress(unnormalizedAddrPath, situs);
  writeJson(path.join("data", "address.json"), address);

  // Files (Appraisal Notice)
  files.forEach((f, idx) => {
    const mappedFormat = mapFileFormatFromUrl(f.original_url);
    if (mappedFormat === "pdf") {
      // Unknown enum value per schema; raise error and skip file write
      console.log(
        JSON.stringify({
          type: "error",
          message: "Unknown enum value pdf.",
          path: "file.file_format",
        }),
      );
      return;
    }
    // If CID is required but not available, also surface a separate blocking message
    // (Requesting CID rather than fabricating)
    if (!f.ipfs_url) {
      console.log(
        JSON.stringify({
          type: "error",
          message: "Missing IPFS CID for file.",
          path: "file.ipfs_url",
        }),
      );
      return;
    }
    writeJson(path.join("data", `file_${idx + 1}.json`), {
      name: f.name,
      original_url: f.original_url,
      file_format: mappedFormat,
      ipfs_url: f.ipfs_url,
      document_type: "PropertyImage",
    });
  });

  // Sales: Not created due to missing purchase price in source HTML
}

if (require.main === module) {
  main();
}
